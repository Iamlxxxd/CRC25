CREATE TRIGGER "rtree_network_demo_walk_0_geom_delete" AFTER DELETE ON "network_demo_walk_0" WHEN old."geom" NOT NULL BEGIN DELETE FROM "rtree_network_demo_walk_0_geom" WHERE id = OLD."fid"; END;

