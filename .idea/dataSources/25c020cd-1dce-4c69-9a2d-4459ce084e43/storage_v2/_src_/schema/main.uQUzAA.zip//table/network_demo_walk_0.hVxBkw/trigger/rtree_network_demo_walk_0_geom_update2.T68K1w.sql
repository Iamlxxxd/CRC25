CREATE TRIGGER "rtree_network_demo_walk_0_geom_update2" AFTER UPDATE OF "geom" ON "network_demo_walk_0" WHEN OLD."fid" = NEW."fid" AND (NEW."geom" ISNULL OR ST_IsEmpty(NEW."geom")) BEGIN DELETE FROM "rtree_network_demo_walk_0_geom" WHERE id = OLD."fid"; END;

