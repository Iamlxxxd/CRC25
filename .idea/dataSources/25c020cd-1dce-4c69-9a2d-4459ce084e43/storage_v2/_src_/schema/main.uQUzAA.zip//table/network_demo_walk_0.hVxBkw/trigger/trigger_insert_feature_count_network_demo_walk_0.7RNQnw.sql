CREATE TRIGGER "trigger_insert_feature_count_network_demo_walk_0" AFTER INSERT ON "network_demo_walk_0" BEGIN UPDATE gpkg_ogr_contents SET feature_count = feature_count + 1 WHERE lower(table_name) = lower('network_demo_walk_0'); END;

