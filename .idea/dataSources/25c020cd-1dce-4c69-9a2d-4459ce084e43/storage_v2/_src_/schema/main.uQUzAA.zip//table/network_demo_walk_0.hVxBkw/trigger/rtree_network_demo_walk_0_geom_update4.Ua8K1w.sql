CREATE TRIGGER "rtree_network_demo_walk_0_geom_update4" AFTER UPDATE ON "network_demo_walk_0" WHEN OLD."fid" != NEW."fid" AND (NEW."geom" ISNULL OR ST_IsEmpty(NEW."geom")) BEGIN DELETE FROM "rtree_network_demo_walk_0_geom" WHERE id IN (OLD."fid", NEW."fid"); END;

