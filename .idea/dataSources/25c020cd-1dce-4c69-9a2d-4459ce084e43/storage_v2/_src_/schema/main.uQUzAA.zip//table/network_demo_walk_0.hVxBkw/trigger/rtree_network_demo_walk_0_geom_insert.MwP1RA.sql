CREATE TRIGGER "rtree_network_demo_walk_0_geom_insert" AFTER INSERT ON "network_demo_walk_0" WHEN (new."geom" NOT NULL AND NOT ST_IsEmpty(NEW."geom")) BEGIN INSERT OR REPLACE INTO "rtree_network_demo_walk_0_geom" VALUES (NEW."fid",ST_MinX(NEW."geom"), ST_MaxX(NEW."geom"),ST_MinY(NEW."geom"), ST_MaxY(NEW."geom")); END;

