CREATE TRIGGER "rtree_network_demo_walk_3_geom_delete" AFTER DELETE ON "network_demo_walk_3" WHEN old."geom" NOT NULL BEGIN DELETE FROM "rtree_network_demo_walk_3_geom" WHERE id = OLD."fid"; END;

